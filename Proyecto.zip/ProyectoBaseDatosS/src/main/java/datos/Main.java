package datos;

import interfaz.login;

public class Main {
    public static void main(String[] args){
        login Login = new login();
        Login.setVisible(true);
    }
}