package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class conexion {
    public static Connection con = null;
    public static String driver = "com.mysql.jdbc.Driver";

    public void conectar() {
        try {
            //aqui se pone el nombre de la base de datos y debe activarse xampp
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/basefinal", "root", "");
            if (con != null) {
                System.out.println("La base de datos se conectó con exito");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Hubo un error inesperado: " + e.toString());
            System.err.println("Error:" + e);
        }
    }
    public Connection getConnection() {
        return con;
    }
}